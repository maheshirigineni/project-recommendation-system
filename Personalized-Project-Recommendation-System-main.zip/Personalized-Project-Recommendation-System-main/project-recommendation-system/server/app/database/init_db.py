from app.database.connection import engine
from app.database.base import Base
from app.models.project import Project
# Import all models
from app.models.user import User

Base.metadata.create_all(bind=engine)